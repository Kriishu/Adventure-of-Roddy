package com.patrickfeltes.game.com.main;

import java.awt.Dimension;

import javax.swing.JPanel;

class gamePanel extends JPanel {
private static final long serialVersionUID = 1L;

public static final int WIDTH = 900;
public static final int HEIGHT = 550;

private Thread thread;
private boolean isRunning = false;


public gamePanel(){
    setPreferredSize(new Dimension(WIDTH,HEIGHT));

    start();
}
 private void start(){
    isRunning = true;
    thread = new Thread((Runnable) this);
    thread.start();
}
public void run(){

}

}
