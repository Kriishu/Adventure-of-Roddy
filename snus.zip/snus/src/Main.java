import java.awt.*;
import javax.swing.*;

public class Main {


    public static void main(String[] args) {

        JFrame frame = new JFrame("The Last Of snus");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel textLabel = new JLabel("Ritvars mekle snus..",SwingConstants.CENTER); textLabel.setPreferredSize(new Dimension(1920, 1080));
        frame.getContentPane().add(textLabel, BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);

    }
}